const express = require('express')
const path = require('path');
const bodyParser = require('body-parser');
const Link = require('./database');
const catchAsync = require('./utill/catchAsync');
const { uploadFile,saveFiles } = require('./utill/uploadfile');
const Apk = require('./models/productModel');

const app = express();
const port = 3000;

app.use(bodyParser.json());


app.post('/uploadApk',
uploadFile.single('file'),
saveFiles,
catchAsync(async (req, res) => {
  const {image,filename,size,downloadPath}=req.body;
const product = await Apk.create({image,name:filename,downloadPath,size:(size/1000000).toFixed(2)});
res.status(201).json({
  status: "success",
  product,
});
}));

app.get('/allapks',catchAsync(  async (req, res) => {
  const data=await Apk.find();
     res.status(200).json({
        data
     }
   );
 })
 );
 app.delete('/apk/:id',catchAsync(  async (req, res) => {
   const {id}=req.params;
   await Apk.findByIdAndDelete(id);
  const data=await Apk.find();
     res.status(200).json({
        data
     }
   );
 })
 );

app.get('/update',catchAsync(async  (req, res) => {
    res.sendFile(path.join(__dirname,'./public/index.html'));
}));
app.get('/uploadapk',catchAsync(async  (req, res) => {
  res.sendFile(path.join(__dirname,'./public/upload.html'));
}));
app.get('/view',catchAsync(async  (req, res) => {
  res.sendFile(path.join(__dirname,'./public/viewAll.html'));
}));

app.get('/:downloadPath', catchAsync( async (req, res) => {
  const {downloadPath}=req.params;
  const apk = await Apk.findOne({ downloadPath });
  console.log(apk);
  if(!apk){
 return res.status(200).json({
    Error:" No apk file on this path"
  })
  }
  const readyFile = path.join(__dirname, `./public/files/${apk.name}`);
  res.download(readyFile);
 
} ));

app.post('/create',catchAsync( async (req, res) => {
  const company = req.body.company;
  const link = req.body.newLink;
 const newOne=await Link.create({ company, link });
    res.status(200).json({
      newOne
    }
  );
}) );

app.patch('/update',catchAsync(  async (req, res) => {
  const link = req.body.newLink;
    const company = req.body.company;
 const newOne=await Link.findOneAndUpdate({ company },{link});
    res.status(200).json({
      newOne
    }
  );
})
);




app.listen(port, () => {
  console.log(`App listening on ${port}`)
});
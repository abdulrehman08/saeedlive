const multer = require("multer");
const catchAsync = require("./catchAsync");

// file uploads
const fileStorage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, "public/files/");
    },
    filename: function (req, file, cb) {
      cb(null, file.originalname);
    },
  });
//  file filter 
  const fileFilter = (req, file, cb) => {
    console.log("file filtered");
    // temporary filtration ignored
    if (true) {
      cb(null, true);
    } else {
      cb(new AppError("Please upload correct file", 400), false);
    }
  };
  
const fileUpload = multer({
    storage: fileStorage,
    fileFilter: fileFilter,
  });
  
  exports.uploadFile = fileUpload;
  //save to the database in image array
  exports.saveFiles = catchAsync(async (req, res, next) => {
    console.log(req.file);
    if (req.file.fieldname=='image') {
      req.body.image=req.file.filename;
    }
    if (req.file.fieldname=='file') {
      req.body.filename=req.file.filename;
      req.body.size=req.file.size;
    }
    next();
  });

exports.addProduct = catchAsync(async (req, res) => {
    const {image,name,size,}=req.body;
  const product = await Product.create({image,name,size:(size/1000000).toFixed(2)});
  res.status(201).json({
    status: "success",
    product,
  });
})
exports.getDownloadskhfd=catchAsync(async (req, res) => {
  const {title}=req.params;
console.log({title});
const {file,downloads} = await Apk.findOne({title});
await Apk.findOneAndUpdate({title},{downloads:downloads+1})
console.log({downloads});
  const readyFile = path.join(__dirname, `../public/apk/${file}`);
  res.download(readyFile);
  // console.log('dowloaded');
  // res.sendFile(readyFile);
});
exports.getDownload = catchAsync(async (req, res) => {
  const {id}=req.params;
const {name,downloads} = await Product.findById(id);
await Product.findByIdAndUpdate(id,{downloads:downloads+1})
  const readyFile = path.join(__dirname, `../public/img/${name}`);
  res.download(readyFile);
});
exports.deleteProduct = catchAsync(async (req, res) => {
  const id=req.params.id;
const product = await Product.findByIdAndDelete(id);
res.status(200).json({
  status: "success",
  product,
});
})
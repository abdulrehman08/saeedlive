const mongoose = require('mongoose');

// database connection
// mongodb+srv://saeed:<password>@cluster0.hmnzx.mongodb.net/myFirstDatabase?retryWrites=true&w=majority
mongoose.connect('mongodb+srv://saeed:saeed@1234@cluster0.hmnzx.mongodb.net/updateLinks?retryWrites=true&w=majority',
    { useNewUrlParser: true, useUnifiedTopology: true }, (error => {
        if (error) {
            console.log(error);
        } else {
            console.log('database connected!!!');
        }
}));

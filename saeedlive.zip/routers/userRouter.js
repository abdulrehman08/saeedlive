const express = require("express");
const Router = express.Router();
const authController = require("../controller/authController");
const userController = require("../controller/userController");
Router.use(authController.protect);
Router.get("/me", userController.getMe);

module.exports = Router;
